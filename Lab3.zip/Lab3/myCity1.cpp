#include <iostream>
using namespace std;


int main()
{

   double fridayTemperature = 101;
   double saturdayTemperature = 88;
   double sundayTemperature = 91;
   double mondayTemperature  = 87;
   double tuesdayTemperature = 79;

   cout << "Pleasanton, California forecast high temperatures:" << endl;
   cout << "Friday, Sept 11, " << fridayTemperature << " degrees" << endl;
   cout << "Saturday, Sept 12, " << saturdayTemperature << " degrees" << endl;
   cout << "Sunday, Sept 13, " << sundayTemperature << " degrees" << endl;
   cout << "Monday, Sept 14, " << mondayTemperature << " degrees" << endl;
   cout << "Tuesday, Sept 15, " << tuesdayTemperature << " degrees" << endl;
   cout << "source: weather.com" << endl;
   cout << "Enjoy the weather!" << endl;
}