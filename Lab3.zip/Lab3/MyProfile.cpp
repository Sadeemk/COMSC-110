#include <iostream>
#include <string>
using namespace std;


int main()
{
   int age ;
   double birthWeight;
   string firstName;
   char gender;

   age = 17;
   birthWeight = 10.9;
   firstName = "Sadeem"; 
   gender = 'M';


   cout << "My age is " << age << endl;
   cout << "My birth weight was " << birthWeight << endl;
   cout << "My first name is " << firstName << endl;
   cout << "My gender is " << gender << endl;
}